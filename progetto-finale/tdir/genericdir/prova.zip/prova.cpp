#include <bits/stdc++.h>

int main() {
	printf("If it works, the file has been sent and retrieved correctly !\n");
	char c = getchar();
	return EXIT_SUCCESS;	
}

